"""Iris AI Predictor - a simple AI-powered web app built with Streamlit + Scikit-learn."""
import pandas as pd
import streamlit as st
from model import load_data, train, predict, compare_models

st.set_page_config(page_title="Iris AI Predictor", page_icon="🌸", layout="centered")

st.title("🌸 Iris AI Predictor")
st.write("Move the sliders to enter flower measurements. The machine learning model "
         "predicts the Iris species and shows how confident it is.")

X, y, feature_names, species = load_data()

# Sidebar: choose model
st.sidebar.header("Settings")
model_name = st.sidebar.selectbox("Choose a model", ["Logistic Regression", "Decision Tree", "K-Nearest Neighbors"])


@st.cache_resource
def get_model(name):
    return train(name)


model, acc = get_model(model_name)
st.sidebar.metric("Test accuracy", f"{acc:.1%}")

# Inputs
st.subheader("Flower measurements (cm)")
features = []
cols = st.columns(2)
for i, name in enumerate(feature_names):
    lo, hi = float(X[:, i].min()), float(X[:, i].max())
    with cols[i % 2]:
        features.append(st.slider(name.title(), lo, hi, float(X[:, i].mean()), 0.1))

# Prediction
if st.button("Predict species", type="primary"):
    label, probs = predict(model, features)
    st.success(f"Predicted species: **{label.title()}**")
    st.bar_chart(pd.DataFrame({"Probability": probs}))
    for s, p in probs.items():
        st.write(f"{s.title()}: {p:.1%}")

# Model comparison
with st.expander("Compare all models"):
    scores = compare_models()
    st.bar_chart(pd.Series(scores, name="Accuracy"))

# Data
with st.expander("View dataset"):
    df = pd.DataFrame(X, columns=feature_names)
    df["species"] = [species[i] for i in y]
    st.dataframe(df)

st.caption("Built as an AI Tools & Mini Project - uses Scikit-learn and Streamlit.")
