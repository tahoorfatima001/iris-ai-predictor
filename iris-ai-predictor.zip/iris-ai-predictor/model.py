"""Model logic for the Iris AI Predictor (kept separate from the UI so it is easy to test)."""
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

MODELS = {
    "Logistic Regression": lambda: LogisticRegression(max_iter=200),
    "Decision Tree": lambda: DecisionTreeClassifier(random_state=42),
    "K-Nearest Neighbors": lambda: KNeighborsClassifier(n_neighbors=5),
}


def load_data():
    iris = load_iris()
    return iris.data, iris.target, list(iris.feature_names), [str(s) for s in iris.target_names]


def train(model_name="Logistic Regression", test_size=0.2, seed=42):
    """Train the chosen model and return (model, accuracy)."""
    X, y, _, _ = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=seed, stratify=y
    )
    model = MODELS[model_name]()
    model.fit(X_train, y_train)
    acc = accuracy_score(y_test, model.predict(X_test))
    return model, acc


def predict(model, features):
    """Return (species_name, {species: probability}) for one flower."""
    _, _, _, species = load_data()
    x = np.array(features, dtype=float).reshape(1, -1)
    pred = int(model.predict(x)[0])
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(x)[0]
    else:
        probs = np.eye(len(species))[pred]
    return species[pred], {s: float(p) for s, p in zip(species, probs)}


def compare_models():
    """Accuracy of every model on the same test split."""
    return {name: train(name)[1] for name in MODELS}
