# AI Tools Exploration Report

**Author:** Tahoor Fatima
**Module:** 5: AI Tools & Mini Project

## 1. Tools Explored
| Tool | What it is | Best used for |
|------|-----------|---------------|
| **ChatGPT** (OpenAI) | General-purpose AI chat assistant | Explaining concepts, writing and debugging code, drafting text |
| **Gemini** (Google) | Google's AI assistant, integrated with Google apps | Research, summarising information, working with Google Colab/Docs |
| **Microsoft Copilot** | AI assistant integrated into Microsoft products and GitHub | Coding help in editors, Office productivity, quick answers with web sources |

## 2. How AI Tools Help

### Coding
- Generate starter code (for example a Streamlit layout or a Scikit-learn pipeline)
- Explain error messages and suggest fixes
- Explain unfamiliar code line by line
- Suggest improvements such as separating logic (`model.py`) from the interface (`app.py`)

### Research
- Summarise topics quickly (for example, the difference between classification algorithms)
- Compare options and list pros and cons
- Point to concepts worth studying further

### Productivity
- Draft and polish emails, reports, and LinkedIn posts
- Create study plans and checklists
- Turn rough notes into structured documents

## 3. Mini Project: Iris AI Predictor
I improved my Module 4 *Machine Learning Fundamentals* notebook by turning it into an interactive web app. Users enter flower measurements and the trained model predicts the species with confidence scores.

**How AI tools supported the project:**
- Planning the app structure and features
- Understanding how to use Streamlit widgets and caching
- Debugging and reviewing the code
- Writing documentation

## 4. Limitations and Responsible Use
- AI can give wrong or outdated answers, so I tested all code myself.
- AI output should be understood before use, not just copied.
- Sensitive or private data should not be pasted into public AI tools.
- AI is a helper; the thinking, checking, and decisions stay with me.

## 5. Key Learnings
1. Good prompts (clear, specific, with context) give much better answers.
2. AI speeds up learning and coding, but verification is essential.
3. Combining a simple ML model with a web interface makes a project far more useful and shareable.
4. Clean project structure and a good README make work easier to understand.
