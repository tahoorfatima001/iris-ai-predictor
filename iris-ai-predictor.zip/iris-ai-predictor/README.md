# Iris AI Predictor

A simple AI-powered web app that predicts the species of an Iris flower (Setosa, Versicolor, or Virginica) from its measurements. Built as my **AI Tools & Mini Project** (Module 5), improving on my earlier *Machine Learning Fundamentals* notebook by turning the model into an interactive app.

## Features
- Interactive sliders for sepal and petal measurements
- Prediction with a confidence (probability) chart
- Choose between 3 models: Logistic Regression, Decision Tree, K-Nearest Neighbors
- Model accuracy shown on unseen test data
- Compare all models and view the dataset

## Tech Stack
Python, Scikit-learn, Pandas, NumPy, Streamlit

## Project Structure
```
iris-ai-predictor/
├── app.py                 # Streamlit user interface
├── model.py               # Model training and prediction logic
├── requirements.txt       # Dependencies
├── AI_TOOLS_REPORT.md     # How I used AI tools (ChatGPT, Gemini, Copilot)
└── README.md
```

## How to Run
```bash
git clone https://github.com/<your-username>/iris-ai-predictor.git
cd iris-ai-predictor
pip install -r requirements.txt
streamlit run app.py
```
Then open the local URL shown in the terminal (usually http://localhost:8501).

## How It Works
1. Load the Iris dataset (150 flowers, 4 features, 3 species)
2. Split into 80% training and 20% testing data
3. Train the selected model with Scikit-learn
4. Predict the species for the measurements chosen by the user
5. Display the result with probabilities

## AI Tools Used
I used AI assistants to learn, plan, and debug this project. See [AI_TOOLS_REPORT.md](AI_TOOLS_REPORT.md).

## Author
**Tahoor Fatima**: BS Economics and Data Science
